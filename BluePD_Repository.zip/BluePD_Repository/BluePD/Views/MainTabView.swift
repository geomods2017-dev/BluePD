import SwiftUI

struct MainTabView: View {
    @EnvironmentObject private var appState: AppState
    @EnvironmentObject private var themeManager: ThemeManager

    var body: some View {
        TabView(selection: $appState.selectedTab) {
            DashboardView()
                .tabItem { Label("Home", systemImage: "house.fill") }
                .tag(AppTab.home)

            MirandaView()
                .tabItem { Label("Miranda", systemImage: "quote.bubble.fill") }
                .tag(AppTab.miranda)

            CaseLawView()
                .tabItem { Label("Case Law", systemImage: "books.vertical.fill") }
                .tag(AppTab.caseLaw)

            StatesListView()
                .tabItem { Label("State Codes", systemImage: "map.fill") }
                .tag(AppTab.states)

            EvidenceView()
                .tabItem { Label("Evidence", systemImage: "camera.fill") }
                .tag(AppTab.evidence)

            SettingsView()
                .tabItem { Label("Settings", systemImage: "gearshape.fill") }
                .tag(AppTab.settings)
        }
        .tint(themeManager.accentColor)
    }
}
