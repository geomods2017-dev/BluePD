import SwiftUI

struct EvidenceDetailView: View {
    @EnvironmentObject private var evidenceStore: EvidenceStore
    let item: EvidenceItem

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                if let image = evidenceStore.image(for: item) {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .clipShape(RoundedRectangle(cornerRadius: 18))
                }

                BluePDCard(title: "Metadata", systemImage: "doc.text.magnifyingglass") {
                    Text("Officer: \(item.officerName)")
                    Text("Case #: \(item.caseNumber.isEmpty ? "N/A" : item.caseNumber)")
                    Text("Captured: \(item.timestamp.formatted(date: .abbreviated, time: .shortened))")
                    Text("SHA-256: \(item.sha256)")
                        .font(.footnote.monospaced())
                        .textSelection(.enabled)
                }

                BluePDCard(title: "Notes", systemImage: "note.text") {
                    Text(item.notes.isEmpty ? "No notes entered." : item.notes)
                }
            }
            .padding()
        }
        .navigationTitle(item.title)
        .navigationBarTitleDisplayMode(.inline)
    }
}
