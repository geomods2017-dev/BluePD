import SwiftUI

struct CaseLawView: View {
    @EnvironmentObject private var legalStore: LegalStore

    var body: some View {
        NavigationStack {
            List(legalStore.caseLaw) { item in
                VStack(alignment: .leading, spacing: 8) {
                    Text(item.title)
                        .font(.headline)
                    Text(item.citation)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    Text(item.summary)
                        .font(.subheadline)
                    Divider()
                    Text("Holding: \(item.keyHolding)")
                        .font(.footnote)
                    Text("Court: \(item.court) • Jurisdiction: \(item.jurisdiction) • Decided: \(item.decidedOn)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding(.vertical, 6)
            }
            .navigationTitle("New Case Law")
        }
    }
}
