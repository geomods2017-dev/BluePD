import SwiftUI

struct LoginView: View {
    @EnvironmentObject private var authViewModel: AuthViewModel
    @EnvironmentObject private var themeManager: ThemeManager

    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(colors: [themeManager.accentColor.opacity(0.7), .black], startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea()

                VStack(spacing: 20) {
                    Image(systemName: "shield.lefthalf.filled.badge.checkmark")
                        .font(.system(size: 62))
                        .foregroundStyle(.white)

                    Text(themeManager.officerProfile.agencyName)
                        .font(.largeTitle.bold())
                        .foregroundStyle(.white)

                    VStack(spacing: 12) {
                        TextField("Username", text: $authViewModel.username)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .padding()
                            .background(Color.white)
                            .clipShape(RoundedRectangle(cornerRadius: 14))

                        SecureField("Password", text: $authViewModel.password)
                            .padding()
                            .background(Color.white)
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                    }

                    VStack(spacing: 12) {
                        Button("Login") { authViewModel.login() }
                            .buttonStyle(.borderedProminent)
                            .tint(themeManager.accentColor)
                            .frame(maxWidth: .infinity)

                        Button("Save / Update Credentials") { authViewModel.registerOrUpdateCredentials() }
                            .buttonStyle(.bordered)
                            .foregroundStyle(.white)

                        if authViewModel.biometricsEnabled {
                            Button("Login with Face ID / Touch ID") {
                                Task { await authViewModel.loginWithBiometrics() }
                            }
                            .buttonStyle(.bordered)
                            .foregroundStyle(.white)
                        }
                    }

                    Toggle("Remember username", isOn: Binding(
                        get: { authViewModel.rememberUsername },
                        set: {
                            authViewModel.updateRememberUsername($0)
                        }
                    ))
                    .foregroundStyle(.white)
                    .padding(.top, 8)

                    if !authViewModel.errorMessage.isEmpty {
                        Text(authViewModel.errorMessage)
                            .font(.footnote)
                            .foregroundStyle(.white)
                            .multilineTextAlignment(.center)
                    }
                }
                .padding(24)
            }
        }
    }
}
