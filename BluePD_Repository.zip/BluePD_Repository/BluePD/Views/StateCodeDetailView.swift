import SwiftUI

struct StateCodeDetailView: View {
    let stateCode: StateCode
    @State private var showWebView = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                BluePDCard(title: stateCode.state, systemImage: "building.columns.fill") {
                    Text(stateCode.summary)
                    Text("Category: \(stateCode.categoryLabel)")
                        .foregroundStyle(.secondary)
                    Text("Source: \(stateCode.sourceName)")
                        .foregroundStyle(.secondary)
                }

                BluePDCard(title: "Notes", systemImage: "list.bullet.rectangle.portrait.fill") {
                    ForEach(stateCode.notes, id: \.self) { note in
                        Text("• \(note)")
                    }
                }

                if let rawURL = stateCode.sourceURL, let url = URL(string: rawURL) {
                    Button("Open Source") {
                        showWebView = true
                    }
                    .buttonStyle(.borderedProminent)
                    .sheet(isPresented: $showWebView) {
                        NavigationStack {
                            WebView(url: url)
                                .navigationTitle(stateCode.abbreviation)
                                .navigationBarTitleDisplayMode(.inline)
                        }
                    }
                } else {
                    Text("Add an official statute source URL in States.json for live in-app browsing.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            .padding()
        }
        .navigationTitle(stateCode.state)
    }
}
