import SwiftUI
import UIKit

struct EvidenceView: View {
    @EnvironmentObject private var evidenceStore: EvidenceStore
    @EnvironmentObject private var themeManager: ThemeManager
    @State private var showingCamera = false
    @State private var capturedImage: UIImage?
    @State private var caseNumber = ""
    @State private var title = ""
    @State private var notes = ""
    @State private var errorMessage = ""

    var body: some View {
        NavigationStack {
            List {
                Section("Capture") {
                    TextField("Case number", text: $caseNumber)
                    TextField("Evidence title", text: $title)
                    TextField("Notes", text: $notes, axis: .vertical)
                        .lineLimit(3, reservesSpace: true)

                    Button("Open Camera") { showingCamera = true }

                    if let capturedImage {
                        Image(uiImage: capturedImage)
                            .resizable()
                            .scaledToFit()
                            .frame(maxHeight: 220)
                            .clipShape(RoundedRectangle(cornerRadius: 16))

                        Button("Save Evidence") {
                            do {
                                try evidenceStore.addEvidence(
                                    image: capturedImage,
                                    officerName: themeManager.officerProfile.officerDisplayName,
                                    caseNumber: caseNumber,
                                    title: title.isEmpty ? "Evidence Photo" : title,
                                    notes: notes
                                )
                                self.capturedImage = nil
                                caseNumber = ""
                                title = ""
                                notes = ""
                                errorMessage = ""
                            } catch {
                                errorMessage = "Unable to save evidence."
                            }
                        }
                        .buttonStyle(.borderedProminent)
                    }
                }

                if !errorMessage.isEmpty {
                    Section {
                        Text(errorMessage)
                            .foregroundStyle(.red)
                    }
                }

                Section("Evidence Locker") {
                    ForEach(evidenceStore.items) { item in
                        NavigationLink {
                            EvidenceDetailView(item: item)
                        } label: {
                            VStack(alignment: .leading, spacing: 6) {
                                Text(item.title)
                                    .font(.headline)
                                Text("Case #: \(item.caseNumber.isEmpty ? "N/A" : item.caseNumber)")
                                    .font(.subheadline)
                                Text(item.timestamp.formatted(date: .abbreviated, time: .shortened))
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                    .onDelete(perform: evidenceStore.deleteEvidence)
                }
            }
            .navigationTitle("Evidence")
            .sheet(isPresented: $showingCamera) {
                CameraPicker(image: $capturedImage)
            }
        }
    }
}
