import SwiftUI

struct DashboardView: View {
    @EnvironmentObject private var themeManager: ThemeManager
    @EnvironmentObject private var evidenceStore: EvidenceStore
    @EnvironmentObject private var legalStore: LegalStore

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Text("Welcome, \(themeManager.officerProfile.officerDisplayName)")
                        .font(.largeTitle.bold())

                    Text("Police reference, case law notes, state code access, and evidence capture in one place.")
                        .foregroundStyle(.secondary)

                    BluePDCard(title: "Quick Stats", systemImage: "chart.bar.fill") {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Saved evidence items: \(evidenceStore.items.count)")
                            Text("Available state entries: \(legalStore.stateCodes.count)")
                            Text("Case law briefings: \(legalStore.caseLaw.count)")
                        }
                    }

                    BluePDCard(title: "Officer Profile", systemImage: "person.text.rectangle.fill") {
                        Text("Agency: \(themeManager.officerProfile.agencyName)")
                        Text("Display Name: \(themeManager.officerProfile.officerDisplayName)")
                        if !themeManager.officerProfile.badgeNumber.isEmpty {
                            Text("Badge #: \(themeManager.officerProfile.badgeNumber)")
                        }
                    }

                    BluePDCard(title: "Version 2 Upgrades", systemImage: "arrow.up.circle.fill") {
                        Text("This build adds a cleaner architecture, searchable state list, in-app evidence metadata, local hash generation, web-view support for source links, and expanded customization.")
                    }
                }
                .padding()
            }
            .navigationTitle("Blue PD")
        }
    }
}
