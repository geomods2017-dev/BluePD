import SwiftUI

struct StatesListView: View {
    @EnvironmentObject private var legalStore: LegalStore

    var body: some View {
        NavigationStack {
            List(legalStore.filteredStates) { state in
                NavigationLink(value: state) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(state.state)
                            .font(.headline)
                        Text(state.categoryLabel)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                }
            }
            .searchable(text: $legalStore.searchText, prompt: "Search state or code")
            .navigationTitle("State Codes")
            .navigationDestination(for: StateCode.self) { state in
                StateCodeDetailView(stateCode: state)
            }
        }
    }
}
