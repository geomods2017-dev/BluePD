import SwiftUI

struct MirandaView: View {
    private let mirandaText = "You have the right to remain silent. Anything you say can and will be used against you in a court of law. You have the right to an attorney. If you cannot afford an attorney, one will be appointed for you before any questioning if you wish."

    var body: some View {
        NavigationStack {
            ScrollView {
                BluePDCard(title: "Miranda Warning", systemImage: "exclamationmark.bubble.fill") {
                    Text(mirandaText)
                        .font(.title3)
                        .padding(.top, 4)
                }
                .padding()
            }
            .navigationTitle("Miranda")
        }
    }
}
