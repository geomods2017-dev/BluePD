import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var themeManager: ThemeManager
    @EnvironmentObject private var authViewModel: AuthViewModel

    var body: some View {
        NavigationStack {
            Form {
                Section("Officer") {
                    TextField("Agency name", text: $themeManager.officerProfile.agencyName)
                    TextField("Display name", text: $themeManager.officerProfile.officerDisplayName)
                    TextField("Badge number", text: $themeManager.officerProfile.badgeNumber)
                    Button("Save Profile") { themeManager.saveProfile() }
                }

                Section("Appearance") {
                    Picker("Accent", selection: Binding(
                        get: { themeManager.accent },
                        set: { themeManager.updateAccent($0) }
                    )) {
                        ForEach(AppAccent.allCases) { accent in
                            Text(accent.displayName).tag(accent)
                        }
                    }

                    Picker("Appearance", selection: Binding(
                        get: { themeManager.appearance },
                        set: { themeManager.updateAppearance($0) }
                    )) {
                        ForEach(AppAppearance.allCases) { appearance in
                            Text(appearance.displayName).tag(appearance)
                        }
                    }
                }

                Section("Security") {
                    Toggle("Enable Face ID / Touch ID", isOn: Binding(
                        get: { authViewModel.biometricsEnabled },
                        set: { authViewModel.updateBiometrics($0) }
                    ))
                }

                Section {
                    Button("Log Out", role: .destructive) { authViewModel.logout() }
                }
            }
            .navigationTitle("Settings")
        }
    }
}
