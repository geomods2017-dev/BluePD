import SwiftUI

enum AppAccent: String, CaseIterable, Codable, Identifiable {
    case blue, indigo, teal, red, orange

    var id: String { rawValue }

    var color: Color {
        switch self {
        case .blue: return .blue
        case .indigo: return .indigo
        case .teal: return .teal
        case .red: return .red
        case .orange: return .orange
        }
    }

    var displayName: String { rawValue.capitalized }
}

enum AppAppearance: String, CaseIterable, Codable, Identifiable {
    case system, light, dark

    var id: String { rawValue }

    var displayName: String { rawValue.capitalized }

    var colorScheme: ColorScheme? {
        switch self {
        case .system: return nil
        case .light: return .light
        case .dark: return .dark
        }
    }
}
