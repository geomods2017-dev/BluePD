import Foundation

struct CaseLawItem: Identifiable, Codable {
    let id: UUID
    var title: String
    var court: String
    var decidedOn: String
    var summary: String
    var keyHolding: String
    var citation: String
    var jurisdiction: String
    var isBookmarked: Bool?
}
