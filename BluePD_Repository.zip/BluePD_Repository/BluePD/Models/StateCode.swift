import Foundation

struct StateCode: Identifiable, Codable, Hashable {
    let id: UUID
    let state: String
    let abbreviation: String
    let categoryLabel: String
    let summary: String
    let sourceName: String
    let sourceURL: String?
    let notes: [String]
}
