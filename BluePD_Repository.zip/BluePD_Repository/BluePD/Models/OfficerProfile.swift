import Foundation

struct OfficerProfile: Codable {
    var agencyName: String = "Blue PD"
    var officerDisplayName: String = "Officer"
    var badgeNumber: String = ""
    var username: String = ""
}
