import Foundation

struct EvidenceItem: Identifiable, Codable, Hashable {
    let id: UUID
    var officerName: String
    var caseNumber: String
    var title: String
    var notes: String
    var timestamp: Date
    var fileName: String
    var sha256: String
    var latitude: Double?
    var longitude: Double?
}
