import SwiftUI

@main
struct BluePDApp: App {
    @StateObject private var appState = AppState()
    @StateObject private var authViewModel = AuthViewModel()
    @StateObject private var themeManager = ThemeManager()
    @StateObject private var legalStore = LegalStore()
    @StateObject private var evidenceStore = EvidenceStore()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(appState)
                .environmentObject(authViewModel)
                .environmentObject(themeManager)
                .environmentObject(legalStore)
                .environmentObject(evidenceStore)
                .preferredColorScheme(themeManager.colorScheme)
        }
    }
}
