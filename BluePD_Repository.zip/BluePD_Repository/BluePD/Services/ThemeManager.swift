import SwiftUI

@MainActor
final class ThemeManager: ObservableObject {
    @Published var officerProfile: OfficerProfile
    @Published var accent: AppAccent
    @Published var appearance: AppAppearance

    init() {
        if let profileData = UserDefaults.standard.data(forKey: UserDefaultsKeys.officerProfile),
           let decoded = try? JSONDecoder().decode(OfficerProfile.self, from: profileData) {
            officerProfile = decoded
        } else {
            officerProfile = OfficerProfile()
        }

        accent = AppAccent(rawValue: UserDefaults.standard.string(forKey: UserDefaultsKeys.appAccent) ?? "blue") ?? .blue
        appearance = AppAppearance(rawValue: UserDefaults.standard.string(forKey: UserDefaultsKeys.appAppearance) ?? "system") ?? .system
    }

    var accentColor: Color { accent.color }
    var colorScheme: ColorScheme? { appearance.colorScheme }

    func saveProfile() {
        guard let data = try? JSONEncoder().encode(officerProfile) else { return }
        UserDefaults.standard.set(data, forKey: UserDefaultsKeys.officerProfile)
    }

    func updateAccent(_ value: AppAccent) {
        accent = value
        UserDefaults.standard.set(value.rawValue, forKey: UserDefaultsKeys.appAccent)
    }

    func updateAppearance(_ value: AppAppearance) {
        appearance = value
        UserDefaults.standard.set(value.rawValue, forKey: UserDefaultsKeys.appAppearance)
    }
}
