import Foundation
import UIKit

@MainActor
final class EvidenceStore: ObservableObject {
    @Published private(set) var items: [EvidenceItem] = []
    private let crypto = FileCryptoService()

    init() {
        loadItems()
    }

    func addEvidence(image: UIImage, officerName: String, caseNumber: String, title: String, notes: String) throws {
        guard let data = image.jpegData(compressionQuality: 0.9) else { return }
        let id = UUID()
        let fileName = id.uuidString + ".jpg"
        let url = documentsURL().appendingPathComponent(fileName)
        try data.write(to: url, options: .atomic)

        let item = EvidenceItem(
            id: id,
            officerName: officerName,
            caseNumber: caseNumber,
            title: title,
            notes: notes,
            timestamp: Date(),
            fileName: fileName,
            sha256: crypto.sha256Hex(for: data),
            latitude: nil,
            longitude: nil
        )
        items.insert(item, at: 0)
        persistItems()
    }

    func deleteEvidence(at offsets: IndexSet) {
        for index in offsets {
            let item = items[index]
            try? FileManager.default.removeItem(at: documentsURL().appendingPathComponent(item.fileName))
        }
        items.remove(atOffsets: offsets)
        persistItems()
    }

    func image(for item: EvidenceItem) -> UIImage? {
        UIImage(contentsOfFile: documentsURL().appendingPathComponent(item.fileName).path)
    }

    private func documentsURL() -> URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
    }

    private func persistItems() {
        guard let data = try? JSONEncoder().encode(items) else { return }
        UserDefaults.standard.set(data, forKey: UserDefaultsKeys.evidenceItems)
    }

    private func loadItems() {
        guard let data = UserDefaults.standard.data(forKey: UserDefaultsKeys.evidenceItems),
              let decoded = try? JSONDecoder().decode([EvidenceItem].self, from: data) else {
            items = []
            return
        }
        items = decoded.sorted { $0.timestamp > $1.timestamp }
    }
}
