import Foundation

enum UserDefaultsKeys {
    static let isLoggedIn = "isLoggedIn"
    static let officerProfile = "officerProfile"
    static let appAccent = "appAccent"
    static let appAppearance = "appAppearance"
    static let evidenceItems = "evidenceItems"
    static let biometricsEnabled = "biometricsEnabled"
    static let rememberUsername = "rememberUsername"
}
