import Foundation

@MainActor
final class AuthViewModel: ObservableObject {
    @Published var username = ""
    @Published var password = ""
    @Published var isLoggedIn = UserDefaults.standard.bool(forKey: UserDefaultsKeys.isLoggedIn)
    @Published var biometricsEnabled = UserDefaults.standard.bool(forKey: UserDefaultsKeys.biometricsEnabled)
    @Published var rememberUsername = UserDefaults.standard.bool(forKey: UserDefaultsKeys.rememberUsername)
    @Published var errorMessage = ""

    private let biometricService = BiometricAuthService()

    func registerOrUpdateCredentials() {
        guard !username.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              !password.isEmpty else {
            errorMessage = "Enter a username and password."
            return
        }

        if KeychainHelper.shared.save(username: username, password: password) {
            if rememberUsername {
                UserDefaults.standard.set(username, forKey: "rememberedUsername")
            }
            errorMessage = "Credentials saved."
        } else {
            errorMessage = "Unable to save credentials."
        }
    }

    func loadRememberedUsername() {
        guard rememberUsername else { return }
        username = UserDefaults.standard.string(forKey: "rememberedUsername") ?? ""
    }

    func login() {
        guard let stored = KeychainHelper.shared.readPassword(username: username), stored == password else {
            errorMessage = "Invalid username or password."
            return
        }

        isLoggedIn = true
        UserDefaults.standard.set(true, forKey: UserDefaultsKeys.isLoggedIn)
        errorMessage = ""
    }

    func loginWithBiometrics() async {
        let success = await biometricService.authenticate(reason: "Unlock Blue PD")
        if success {
            isLoggedIn = true
            UserDefaults.standard.set(true, forKey: UserDefaultsKeys.isLoggedIn)
            errorMessage = ""
        } else {
            errorMessage = "Biometric authentication failed."
        }
    }

    func logout() {
        isLoggedIn = false
        UserDefaults.standard.set(false, forKey: UserDefaultsKeys.isLoggedIn)
        password = ""
    }

    func updateBiometrics(_ enabled: Bool) {
        biometricsEnabled = enabled
        UserDefaults.standard.set(enabled, forKey: UserDefaultsKeys.biometricsEnabled)
    }

    func updateRememberUsername(_ enabled: Bool) {
        rememberUsername = enabled
        UserDefaults.standard.set(enabled, forKey: UserDefaultsKeys.rememberUsername)
        if enabled {
            UserDefaults.standard.set(username, forKey: "rememberedUsername")
        }
    }
}
