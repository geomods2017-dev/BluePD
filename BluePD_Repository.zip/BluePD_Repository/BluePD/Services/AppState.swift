import Foundation

@MainActor
final class AppState: ObservableObject {
    @Published var selectedTab: AppTab = .home
    @Published var lastErrorMessage: String?
}

enum AppTab: Hashable {
    case home, miranda, caseLaw, states, evidence, settings
}
