import Foundation

@MainActor
final class LegalStore: ObservableObject {
    @Published var stateCodes: [StateCode] = []
    @Published var caseLaw: [CaseLawItem] = []
    @Published var searchText = ""

    init() {
        loadStateCodes()
        loadCaseLaw()
    }

    var filteredStates: [StateCode] {
        guard !searchText.isEmpty else { return stateCodes }
        return stateCodes.filter {
            $0.state.localizedCaseInsensitiveContains(searchText) ||
            $0.abbreviation.localizedCaseInsensitiveContains(searchText) ||
            $0.summary.localizedCaseInsensitiveContains(searchText)
        }
    }

    private func loadStateCodes() {
        guard let url = Bundle.main.url(forResource: "States", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let decoded = try? JSONDecoder().decode([StateCode].self, from: data) else {
            stateCodes = []
            return
        }
        stateCodes = decoded.sorted { $0.state < $1.state }
    }

    private func loadCaseLaw() {
        guard let url = Bundle.main.url(forResource: "CaseLaw", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let decoded = try? JSONDecoder().decode([CaseLawItem].self, from: data) else {
            caseLaw = []
            return
        }
        caseLaw = decoded
    }
}
