# Blue PD

Blue PD is an iPhone app prototype built with SwiftUI for law-enforcement reference, legal lookup, and field evidence workflows.

## Included in this repository

- `BluePD/` SwiftUI source code
- `BluePD.xcodeproj/` starter Xcode project
- state code and case law JSON resources
- evidence locker and camera workflow scaffolding
- theming and officer personalization support

## Current features

- Username/password login
- Biometric login scaffolding
- Miranda warning reference
- Case law feed scaffold
- 50-state code browser
- In-app statute source viewing
- Evidence photo capture and local storage
- Evidence metadata and SHA-256 hashing
- Officer name and UI customization

## How to use

1. Open `BluePD.xcodeproj` in Xcode.
2. Confirm all files in the `BluePD/` folder are part of the app target.
3. Add these privacy usage descriptions to the app target Info settings:
   - `NSCameraUsageDescription` → `Blue PD uses the camera to capture evidence photos.`
   - `NSPhotoLibraryAddUsageDescription` → `Blue PD stores captured evidence photos in the app.`
4. Build and run.

## Note on the included Xcode project

The included `BluePD.xcodeproj` is a starter project shell. If Xcode does not automatically include all newer Version 2 files, add the missing files from the `BluePD/` folder to the app target manually.

## Suggested next upgrades

- full production-ready Xcode project cleanup
- test targets
- backend auth and sync
- encrypted storage and audit trail
- live state statute feeds
- live case law feed
- role/agency management

## Production note

This repository is a prototype and not a production evidence-management or legal-research platform.
